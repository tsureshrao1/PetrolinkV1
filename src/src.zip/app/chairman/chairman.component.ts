import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chairman',
  templateUrl: './chairman.component.html',
  styleUrls: ['./chairman.component.css']
})
export class ChairmanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
