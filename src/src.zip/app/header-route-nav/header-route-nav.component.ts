import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-route-nav',
  templateUrl: './header-route-nav.component.html',
  styleUrls: ['./header-route-nav.component.css']
})
export class HeaderRouteNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
