import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subsidaries',
  templateUrl: './subsidaries.component.html',
  styleUrls: ['./subsidaries.component.css']
})
export class SubsidariesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
